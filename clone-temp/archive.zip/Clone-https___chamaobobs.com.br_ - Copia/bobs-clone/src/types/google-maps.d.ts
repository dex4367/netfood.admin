declare global {
  interface Window {
    google: typeof google;
  }
}

export {}; 