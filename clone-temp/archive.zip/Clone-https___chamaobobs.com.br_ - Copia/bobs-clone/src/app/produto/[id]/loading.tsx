import { ProductDetailsSkeleton } from "@/components/ui/product-skeleton";

export default function Loading() {
  return <ProductDetailsSkeleton />;
} 